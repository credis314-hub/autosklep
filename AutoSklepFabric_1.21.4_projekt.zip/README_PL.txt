AutoSklep — projekt źródłowy Fabric 1.21.4

Sterowanie:
- K: włącz/wyłącz automat.
- Po włączeniu pierwsza sprzedaż nastąpi po 10 minutach.
- Automat wpisuje /sklep, klika kompas (rząd 3, slot 4), czerwoną wełnę
  (rząd 3, slot 6), a następnie sloty 6, 7 i 8 w drugim rzędzie.
- Dla trzech pozycji używa akcji QUICK_MOVE z przyciskiem 1 jako próby
  odwzorowania Shift + prawy klik.

WAŻNE:
To jest projekt źródłowy, nie gotowy, przetestowany plik JAR. Serwerowe GUI
może mieć inne indeksowanie slotów lub własną obsługę kliknięć. Najpierw
przetestuj na małej ilości przedmiotów. Jeśli serwer interpretuje Shift+prawy
klik inaczej, trzeba dostosować akcję kliknięcia.

Budowanie:
1. Zainstaluj JDK 21.
2. Otwórz katalog projektu w terminalu.
3. Uruchom: gradle build
4. JAR będzie w build/libs/.

Wymagania: Fabric Loader, Fabric API, Minecraft 1.21.4. Sodium i Baritone
mogą pozostać zainstalowane — mod nie wymaga ich API.
